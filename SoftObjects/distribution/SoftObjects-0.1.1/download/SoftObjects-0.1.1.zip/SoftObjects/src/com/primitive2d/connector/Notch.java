package com.primitive2d.connector;

public class Notch {

}
