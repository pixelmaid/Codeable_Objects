package com.primitive2d;

import com.datatype.Point;

class TurtleStruct {
	public static double angle = 0;
	public static boolean pen = true;
	public static Point location = new Point(0,0);
}
