package com.ui;

public class InterfaceObj {

}
