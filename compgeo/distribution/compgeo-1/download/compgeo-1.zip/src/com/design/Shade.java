package com.design;

public class Shade extends Part {

	public Shade(double width, double height){
		super(width,height);
	}
	
	
}
