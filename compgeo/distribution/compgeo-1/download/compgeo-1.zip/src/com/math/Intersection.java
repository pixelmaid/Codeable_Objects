package com.math;

public class Intersection {
	Segment s1;
	Segment s2;
	CompPoint intersectPoint;
	
	
	public Intersection(Segment _s1,Segment _s2,CompPoint _ip){
		s1=_s1;
		s2=_s2;
		intersectPoint = _ip;
	}
}
