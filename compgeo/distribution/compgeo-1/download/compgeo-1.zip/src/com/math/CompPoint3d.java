package com.math;

public class CompPoint3d extends CompPoint {
	private double z;
	public CompPoint3d(double _x, double _y, double _z) {
		super(_x, _y);
		this.z=_z;

	}
	
	public double getZ() {
		return z;
	}

	
	
	
}
